import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent } from './subscriptionpackage-selection-preview-pricing-promotional-section.component';

describe('SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent', () => {
  let component: SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent;
  let fixture: ComponentFixture<SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
