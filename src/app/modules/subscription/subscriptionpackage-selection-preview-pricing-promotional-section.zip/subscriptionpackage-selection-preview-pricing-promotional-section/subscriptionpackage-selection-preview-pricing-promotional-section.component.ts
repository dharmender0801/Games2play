import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscriptionpackage-selection-preview-pricing-promotional-section',
  templateUrl: './subscriptionpackage-selection-preview-pricing-promotional-section.component.html',
  styleUrls: ['./subscriptionpackage-selection-preview-pricing-promotional-section.component.css']
})
export class SubscriptionpackageSelectionPreviewPricingPromotionalSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
